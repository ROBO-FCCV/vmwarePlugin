#!/bin/sh
java -classpath commons-codec-1.11.jar:Http11Protocol.jar com.object_name.scbb.tomcat.http11.KeyMgr
