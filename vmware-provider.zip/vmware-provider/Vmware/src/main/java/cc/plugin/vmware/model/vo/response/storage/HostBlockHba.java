/*
 * Copyright (c). 2020-2020. All rights reserved.
 */

package cc.plugin.vmware.model.vo.response.storage;

/**
 * 主机总线适配器
 *
 * @since 2019 -09-16
 */
public class HostBlockHba extends HostBusAdapter {
    /**
     * Instantiates a new Host block hba.
     */
    public HostBlockHba() {
    }
}
