/*
 * Copyright (c). 2020-2020. All rights reserved.
 */

package cc.plugin.vmware.model.vo.response.vm;

/**
 * 功能描述
 *
 * @since 2019 -10-15
 */
public class SystemType {
}
